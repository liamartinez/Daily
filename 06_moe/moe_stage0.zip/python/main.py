"""
MOE - Stage 0: the silent-movie boss.

Runs on the UNO Q's Linux side (MPU). The webcam + person-detection brick
are Moe's eyes; the LED matrix (driven by sketch.ino on the MCU) is his face.
No speaker yet, so Moe communicates in faces and scrolling text.

State machine (same one as the browser prototype, moe_hq.html):

  SLEEPING -> GREET -> ISSUE_TASK -> WAIT_RETURN -> REACT -> COOLDOWN -> SLEEPING

Stage 0 has no microphone, so there is no "yeah" step and no answer-judging;
missions are trust-type only. Completion = the kid leaves the frame and comes
back, OR presses the optional button, OR Moe's patience runs out (he passes
you anyway - he is a very trusting boss).
"""

import random
import threading
import time

# ---------------------------------------------------------------------------
# App Lab imports. NOTE: these module names have shifted between App Lab
# versions. If the app fails on one of these lines, open the built-in
# "Detect Objects on Camera" example in App Lab and copy ITS import lines
# here (plus the class name it uses). Everything below stays the same.
# ---------------------------------------------------------------------------
from arduino.app_utils import *  # provides App and Bridge
from video_image_classification import VideoImageClassification

# ------------------------------ knobs ---------------------------------------
SIMULATE = False        # True = no camera needed: a fake kid walks by
                        # every 25 s so you can test the whole loop tonight
                        # with just the board on your desk.

CONFIDENCE = 0.60       # how sure the model must be that it saw a person
WAKE_AFTER_S = 1.5      # kid must linger this long before Moe wakes (no
                        # false greetings when someone just walks through)
ABSENT_AFTER_S = 2.5    # no detections for this long = hallway is empty
MISSION_TIME_S = 75     # Moe's patience per mission phase
COOLDOWN_S = 8          # quiet time before Moe re-arms
SCROLL_S_PER_CHAR = 0.42  # keep in sync with SCROLL_STEP_MS in sketch.ino

MISSIONS = [
    "JUMP 3 TIMES",
    "TOUCH BLUE",
    "GET A SPOON",
    "ROAR LIKE A DINO",
    "SPIN AROUND",
    "HIGH 5 A GROWNUP",
]
GREETINGS = ["HEY AGENT!", "PSST! AGENT!", "AGENT! EMERGENCY!"]
PRAISE = ["AMAZING!", "INCREDIBLE!", "TOP AGENT!", "WOW!"]

# --------------------------- Moe's body (MCU) --------------------------------
def face(name):
    """Faces: sleep, neutral, happy, heart, grumpy, think, talk."""
    Bridge.call("show_face", name)

def say(text):
    """Scroll text across the matrix and wait until it has finished."""
    print(f"MOE: {text}")
    Bridge.call("scroll_text", text)
    time.sleep(len(text) * SCROLL_S_PER_CHAR + 1.2)

def button_pressed():
    """Optional button between D2 and GND. Works fine if nothing is wired."""
    try:
        return bool(Bridge.call("take_button"))
    except Exception:
        return False

# --------------------------- Moe's eyes (camera) -----------------------------
last_seen = 0.0
first_seen = None

def on_person(result):
    global last_seen, first_seen
    now = time.time()
    if now - last_seen > ABSENT_AFTER_S:
        first_seen = now  # a new arrival, start the dwell clock
    last_seen = now

camera = VideoImageClassification(confidence=CONFIDENCE, debounce=0.4)
camera.on_detect("person", on_person)

def present():
    return (time.time() - last_seen) < ABSENT_AFTER_S

def dwelling():
    return present() and first_seen and (time.time() - first_seen) >= WAKE_AFTER_S

if SIMULATE:
    def fake_hallway():
        while True:
            time.sleep(25)
            print("(simulated kid enters)")
            for _ in range(40):          # ~8 s of "detections"
                on_person(None)
                time.sleep(0.2)
            print("(simulated kid leaves)")
            time.sleep(6)                # gone for a bit...
            for _ in range(25):          # ...and comes back = mission done
                on_person(None)
                time.sleep(0.2)
    threading.Thread(target=fake_hallway, daemon=True).start()

# --------------------------- Moe's brain (states) ----------------------------
missions_done = 0

def wait_for(condition, timeout_s):
    t0 = time.time()
    while time.time() - t0 < timeout_s:
        if condition():
            return True
        time.sleep(0.1)
    return False

def run_moe():
    global missions_done
    state = "SLEEPING"
    face("sleep")
    print("MOE-1 online. Watching the hallway.")

    while True:
        if state == "SLEEPING":
            wait_for(dwelling, 10 ** 9)      # nap until a kid lingers
            print("-> GREET (person dwelling in frame)")
            state = "GREET"

        elif state == "GREET":
            face("happy")
            say(random.choice(GREETINGS))
            state = "ISSUE_TASK"

        elif state == "ISSUE_TASK":
            mission = random.choice(MISSIONS)
            print("-> ISSUE_TASK:", mission)
            say(mission)
            face("think")                    # Moe waits, chin on fist
            state = "WAIT_RETURN"

        elif state == "WAIT_RETURN":
            # Done = button press, or leaving the frame...
            left = wait_for(lambda: button_pressed() or not present(),
                            MISSION_TIME_S)
            if left and not present():
                face("neutral")
                # ...and coming back. (Timeout still counts - trusting boss.)
                wait_for(lambda: button_pressed() or dwelling(),
                         MISSION_TIME_S)
            print("-> REACT (mission resolved)")
            state = "REACT"

        elif state == "REACT":
            missions_done += 1
            print(f"Mission #{missions_done} complete.")
            face("heart")
            time.sleep(2.0)
            say(random.choice(PRAISE))
            if missions_done % 5 == 0:
                say("PROMOTION!")
            state = "COOLDOWN"

        elif state == "COOLDOWN":
            face("happy")
            wait_for(lambda: not present(), 60)  # wait for an empty hallway
            time.sleep(COOLDOWN_S)
            face("sleep")
            print("-> SLEEPING")
            state = "SLEEPING"

threading.Thread(target=run_moe, daemon=True).start()

App.run()
