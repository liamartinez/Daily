# MOE — Stage 0: the silent-movie boss

Moe is a lazy boss who lives on an Arduino UNO Q. Kids are his agents.
Stage 0 has no speaker or mic yet, so Moe communicates entirely in LED-matrix
faces and scrolling text: he naps, spots a kid via the webcam, wakes up,
scrolls a mission ("GET A SPOON"), waits, and celebrates with a heart face
when the agent returns. Every mission ends in praise — he is a very
trusting boss.

The state machine here is the same one as the browser prototype
(`moe_hq.html`): SLEEPING → GREET → ISSUE_TASK → WAIT_RETURN → REACT →
COOLDOWN → back to sleep. The voice states (listening for "yeah",
judging trivia answers) arrive in Stage 2.

## What you need

- Arduino UNO Q (set up once with App Lab and joined to your Wi-Fi)
- USB webcam (UVC — any normal one)
- USB-C hub **with power-delivery passthrough** + a 5V/3A USB-C charger,
  because the board's single port must carry power *and* the webcam at
  the same time. (Not an Apple dongle — the docs specifically exclude those.)

### No hub yet? Test tonight anyway
Set `SIMULATE = True` at the top of `python/main.py`. A pretend kid walks
past every 25 seconds, "leaves", and "comes back", so you can watch the whole
loop — faces, scrolling missions, heart celebration — with just the board
plugged into your computer over USB-C. Flip it back to `False` when the
hub arrives.

## Install

1. In App Lab, create a new App called **Moe**.
2. In the **Bricks** tab, add **Video Image Classification** and select the
   *person* model. (Let App Lab write the `app.yaml` entry itself — its
   brick id/version will match your install.)
3. Paste `python/main.py` over the app's Python file, and
   `sketch/sketch.ino` over the sketch file.
4. Click **Run**. First run is slow (it downloads the brick's Docker
   container); later runs are much faster.
5. When it works, use **Copy and edit app** and set your copy as the
   **startup app** so Moe boots on power-up in the hallway, no laptop needed.

Optional: wire any pushbutton (or a jumper wire you can tap) between **D2**
and **GND** — that becomes the agents' "I'M DONE!" button. Everything works
without it; missions also complete when the kid leaves the frame and comes
back, or when Moe's patience timer runs out.

## Tuning knobs (top of main.py)

- `MISSIONS`, `GREETINGS`, `PRAISE` — Moe's whole personality. Add lines!
  Keep missions SHORT and UPPERCASE — they scroll at ~0.4 s per character.
- `WAKE_AFTER_S` — how long a kid must linger before Moe wakes (stops him
  greeting everyone who merely walks past).
- `CONFIDENCE` — raise it if Moe keeps waking up for the dog.

Faces are plain 13-character strings in `sketch.ino` — design new ones in the
browser prototype, paste them in.

## Troubleshooting (honest edition)

- **Import errors in main.py**: App Lab's Python module names have shifted
  between versions. Open the built-in *Detect Objects on Camera* example and
  copy its import lines + brick class name into `main.py`. The rest is
  version-independent.
- **`matrix.draw` not found**: some core versions call it `loadFrame`, and
  some name the class `ArduinoLEDMatrix` instead of `Arduino_LED_Matrix`.
  Check the built-in LED matrix example for your install's spelling.
- **Bridge signature complaints** on `show_face(String)` /
  `scroll_text(String)`: check App Lab's Bridge API reference for your
  version's preferred string type; only the signatures change.
- **Serial monitor empty over Wi-Fi**: known quirk — MCU serial output only
  shows over a direct USB connection. Python `print()`s show fine over the
  network, and main.py prints every state transition.
- **Sluggishness**: normal on the 2GB board while the camera container spins
  up. Stage 0 runs one model, so once running it's smooth.

## Roadmap

- **Stage 1** (hub + USB speaker): add Piper TTS — Moe speaks his lines
  instead of scrolling them.
- **Stage 2** (mic): add Vosk keyword listening — the "yeah" step, trivia
  judging, and the full task deck from the browser prototype.
- **Agent ID** (three kids): see the shopping-list discussion — height zones,
  printed ArUco agent badges, or an NFC clock-in reader on the Qwiic port.
